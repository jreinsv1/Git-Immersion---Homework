var days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
var duration = [5,6,7,8,4,5,5];

var $ = function(id) { return document.getElementById(id); };

window.onload = function() {
    //event handlers

};
